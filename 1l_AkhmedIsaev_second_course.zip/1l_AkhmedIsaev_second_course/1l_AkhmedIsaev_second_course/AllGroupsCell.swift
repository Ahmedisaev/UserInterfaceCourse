//
//  AllGroupsCell.swift
//  1l_AkhmedIsaev_second_course
//
//  Created by Ahmed Isaev on 20.12.2022.
//

import UIKit

class AllGroupsCell: UITableViewCell {

    
    @IBOutlet var labelAllGroups: UILabel!
    
    @IBOutlet var imageAllGroups: UIImageView!
    
}
