//
//  GroupTableViewCell.swift
//  1l_AkhmedIsaev_second_course
//
//  Created by Ahmed Isaev on 20.12.2022.
//

import UIKit

class GroupTableViewCell: UITableViewCell {

    @IBOutlet var ImageGroupCell: UIImageView!
    
    @IBOutlet var LabelGroupCell: UILabel!
    
}
