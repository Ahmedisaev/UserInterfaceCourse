//
//  FriendTableViewCell.swift
//  1l_AkhmedIsaev_second_course
//
//  Created by Ahmed Isaev on 20.12.2022.
//

import UIKit

class FriendTableViewCell: UITableViewCell {

    @IBOutlet var ImageFriendCell: UIImageView!
    
    @IBOutlet var LabelFriendCell: UILabel!
}
